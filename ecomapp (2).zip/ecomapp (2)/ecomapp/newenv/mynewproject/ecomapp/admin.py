from django.contrib import admin
from .models import*

# Register your models here.

admin.site.register(contact_up)
admin.site.register(User)
admin.site.register(Add_products)
admin.site.register(Add_to_cart)
admin.site.register(Address)
